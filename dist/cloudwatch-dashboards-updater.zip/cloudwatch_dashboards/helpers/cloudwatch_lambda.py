'''
This module contains code specific to the lambda service
'''
import boto3
import json

from cloudwatch_dashboards.helpers.util import DEBUG, TAG_NAME, DEFAULT_DASHBOARD_NAME, show

CLIENT = None
ALL_LAMBDAS = None
SERVICE_NAME = 'lambda'

# pylint: disable=line-too-long

LAMBDA_METRICS = [
    {'name': 'Invocations'},
    {'name': 'Errors'},
    {'name': 'DeadLetterErrors'},
    {'name': 'Duration'},
    {'name': 'Throttles'},
    {'name': 'IteratorAge'},
    {'name': 'ConcurrentExecutions'},
    {'name': 'UnreservedConcurrentExecutions'}
]

def fetch_all_lambdas():
    '''
        routine to cache the boto3 client and the results of the client.list_functions() call,
        since it is called by the get_dashboard_lambdas() funcs.
    '''
    global CLIENT, ALL_LAMBDAS # pylint: disable=global-statement
    if not CLIENT:
        CLIENT = boto3.client("lambda")
    if not ALL_LAMBDAS:
        ALL_LAMBDAS = CLIENT.list_functions()
    return ALL_LAMBDAS




def get_dashboard_lambdas(prefix, environment):
    '''
      Reads the tags from the lambdas and returns a list of dictionaries.
      Each dict has a key containing the dashboard name, and their values
      have properties that contains a list of all the lambdas that
      are tagged with that dashboard name.
    '''
    list_functions_response = fetch_all_lambdas() # CLIENT.list_functions()
    ret = []
    lambdas_by_dashboard = {}
    offset = len(f'{prefix}-{environment}') + 1
    for func in list_functions_response['Functions']:
        lambda_func = func['FunctionName']
        if f'{prefix}-{environment}' in lambda_func:
            if DEBUG:
                print("\n\n\nlambda_func", lambda_func)
                #print("func", json.dumps(func, indent=4))
                show(func)
            tags = CLIENT.list_tags(Resource=func['FunctionArn'])
            if DEBUG:
                print("tags")
                show(tags)
            dashboard_list = DEFAULT_DASHBOARD_NAME
            if TAG_NAME not in tags['Tags']:
                tags['Tags'][TAG_NAME] = DEFAULT_DASHBOARD_NAME
                    
            dashboard_list = tags['Tags'][TAG_NAME]
            if DEBUG:
                print("dashboard_list", dashboard_list)
            for dashboard_name in dashboard_list.split('[ ,;]'):
                if DEBUG:
                    print("dashboard_name", dashboard_name)

                if dashboard_name not in lambdas_by_dashboard:
                    # make a new dashboard name
                    if DEBUG:
                        print(f"----making a new dashboard object for {dashboard_name}")
                        print(map(lambda m: m['name'], LAMBDA_METRICS))
                    lambdas_by_dashboard[dashboard_name] = {
                        'dashboard_type': 'lambda',
                        'metric_names' : list(map(lambda m: m['name'], LAMBDA_METRICS)),
                        'names' : []
                    }
                lambdas_by_dashboard[dashboard_name]['names'].append(lambda_func[offset:])
    if DEBUG:
        print('lambdas_by_dashboard', json.dumps(lambdas_by_dashboard, indent=4))
        print('offset', offset)

    for key, value in lambdas_by_dashboard.items():
        ret.append({key: value})
    return ret
