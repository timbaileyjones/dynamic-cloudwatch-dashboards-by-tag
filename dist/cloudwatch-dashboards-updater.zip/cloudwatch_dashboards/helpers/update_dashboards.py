
import json
import os

from cloudwatch_dashboards.helpers.create_delete_dashboards import create_dashboard, delete_dashboard, get_existing_dashboards
from cloudwatch_dashboards.helpers.cloudwatch_lambda import get_dashboard_lambdas
from cloudwatch_dashboards.helpers.cloudwatch_apigw import get_dashboard_apigws
from cloudwatch_dashboards.helpers.cloudwatch_dynamodb import get_dashboard_dynamodb
from cloudwatch_dashboards.helpers.cloudwatch_cloudfront import get_dashboard_cloudfront
from cloudwatch_dashboards.helpers.cloudwatch_s3 import get_dashboard_s3

from cloudwatch_dashboards.helpers.util import DEBUG, show


def update_dashboards(event):
    dashboards = []
    prefix = os.getenv("PREFIX", "timba")  # from the environment sections of terraform/lambda_function.tf
    print(json.dumps(event, indent=2))

    source = event['source']
    print("source", source)
    environment = 'dev'
    if source == 'aws.s3': 
        if 'detail' in event:
            detail = event['detail']
            if 'requestParameters' in detail:
                requestParameters = detail['requestParameters']
                string_array = requestParameters['bucketName'].split('-')
                if len(string_array) > 2:
                    prefix = string_array[0]
                    environment = string_array[1]
                    print(f"prefix = {prefix}, environment={environment}")
                
                    new_dashboards = get_dashboard_lambdas(prefix, environment)
    #new_dashboards += get_dashboard_apigws(prefix, environment)
    #new_dashboards += get_dashboard_dynamodb(prefix, environment)
    #new_dashboards += get_dashboard_cloudfront(prefix, environment)
    #new_dashboards += get_dashboard_s3(prefix, environment)
    #new_dashboards = list(filter(lambda db: db, new_dashboards))
    else:
        return {'message', f'unknown source: "{source}"'}
    

    remaining_dashboards = get_existing_dashboards(prefix, environment)
    print('remaining_dashboards')
    show(remaining_dashboards)

    for dashboard in new_dashboards:
        if DEBUG:
            print("dashboard", type(dashboard), dashboard)
            show(dashboard)
        for dashboard_name, details in dashboard.items():
            names = details["names"]
            metric_names = details["metric_names"]
            dashboard_type = details["dashboard_type"]

            create_dashboard(
                prefix=prefix,
                environment=environment,
                dashboard_type=dashboard_type,
                metric_names=metric_names,
                basename=dashboard_name,
                names=names,
            )
            # remove current dashboard from list of remaining dashboards
            remaining_dashboards = list(filter(lambda x: x != f'{prefix}-{environment}-{dashboard_name}-{dashboard_type}', remaining_dashboards))
    # TODO - delete dashboards not replaced:
    for remaining_dashboard in remaining_dashboards:
        delete_dashboard(remaining_dashboard)


    print(f"{len(new_dashboards)} dashboards handled")
    print("cloudwatch_dashboards.py complete! ")
    return  {
        'new_dashboard_count': len(new_dashboards)
    }