#!/usr/bin/env python
import boto3
import sys
            

lambda_client = boto3.client("lambda")
apigw_client = boto3.client("apigateway")
dynamodb_client = boto3.client("dynamodb")
s3_client = boto3.client("s3")


get_rest_apis_response = apigw_client.get_rest_apis()
name_to_id = {}
for api in get_rest_apis_response['items']:
    name_to_id[api['name']] = api['id']
#print('name to id', name_to_id)

dashboards = [
  {               
    "Presentation-Lambdas": {   # WPA-206
      "dashboard_type" : "lambda", 
      "names" : [
        "account-activity-presentation-startup",
        "account-balance-presentation-startup", 
        "cash-movement-presentation-startup", 
                "cash-securityactivity-presentation-startup",
                "corporate-actions-presentation-startup",
        "margin-presentation-startup", 
        "margins-presentation-startup", 
        "security-movement-presentation-startup", 
        "uim-presentation-startup"
      ]
    }
  }, 
  {               
    "Domain-Lambdas": {  # WPA-207
      "dashboard_type" : "lambda", 
      "names" : [  
        "account-activity-domain-getaccountactivity", 
        "account-activity-domain-getreversaleligibility", 
        "account-activity-domain-startup", 
                "account-balance-domain-getaccountvaluation",
                "account-balance-domain-gettradingdollars",
                "cash-movement-domain-createjournalentry",
                "cash-movement-domain-getreversaloffsets",
                "corporate-actions-domain-createoffernotes",
                "corporate-actions-domain-createofferoptions",
                "corporate-actions-domain-createofferresponse",
                "corporate-actions-domain-createvoluntaryoffer",
                "corporate-actions-domain-deleteofferresponse",
                "corporate-actions-domain-getaccountofferhistory",
                "corporate-actions-domain-geteligibleaccounts",
                "corporate-actions-domain-getoffernotes",
                "corporate-actions-domain-getvoluntaryofferdetail",
                "corporate-actions-domain-getvoluntaryoffers",
                "corporate-actions-domain-updateoffernotes",
                "margins-domain-cancelexception",
                "margins-domain-getbalancesbyaccount",
                "margins-domain-getexceptiondetails",
                "margins-domain-gettradeexemptforregt",
                "margins-domain-gettradesduefor15c3_3",
                "margins-domain-gettradesdueforregt",
                "margins-domain-submitexception",
                "margins-domain-updateexception",
        "security-movement-domain-createshareentry", 
        "security-movement-domain-createsharewithcashentry", 
        "security-movement-domain-getreversaloffsets", 
        "uim-domain-retrieveuserinformation"
      ]
    }
  }, 
  {               
    "Integration-Lambdas": {  # WPA-208
      "dashboard_type" : "lambda", 
      "names" : [
        "exception-integration-getexceptiondetails", 
        "exception-integration-gettradeexemptforregt", 
        "exception-integration-gettradesduefor15c3_3", 
                "exception-integration-gettradesdueforregt",
                "exception-integration-updateexception",
                "margins-integration-assignexceptions",
        "margins-integration-getexceptions", 
        "margins-integration-updaterequeststatus", 
        "uim-integration-fetchparmdetails", 
        "uim-integration-fetchuserdetails"
      ]
    }
  }, 
  {               
    "Authorizer-Lambdas": {  # WPA-209
      "dashboard_type" : "lambda", 
      "names" : [
          "aws-lambda-edge-authorizer-lambda", 
          "aws-lambda-edge-authorizer-viewer-response-lambda", 
          "tsa-authorization-lambdaauthorizer", 
          "tsa-authorization"
        ]
      }
  }, 
  {               
    "On-prem-Lambdas": {   # WPA-210
      "dashboard_type" : "lambda", 
      "names": [
        "common-private-on-prem-datapowerproxy"
      ]
    }
  }, 
  {               
    "Data-Ingestion-Lambdas": {  # WPA-211
      "dashboard_type" : "lambda", 
      "names": [
        "exception-dataingestion-exceptionsdataingestion", 
        "uim-parm-dataingestion-loadparmtable", 
        "uim-user-dataingestion-loadusertable"
      ]
    }
  },  
  {               
    "Presentation-APIGWs": {  # WPA-212
      "dashboard_type" : "apigw", 
      "names": [
        "regional-presentation"
      ]
    }
  },  
  {               
    "Domain-APIGWs": {  # WPA-213
      "dashboard_type" : "apigw", 
      "names": [
        "regional-domain"
      ]
    }
  },  
  {               
    "Integration-APIGWs": {  # WPA-214
      "dashboard_type" : "apigw", 
      "names": [
        "regional-integration"
      ]
    }
  },  
  {               
    "On-prem-APIGWs": {  # WPA-215
      "dashboard_type" : "apigw", 
      "names": [
        "private-on-prem"
      ]
    }
  },  
  {               
    "Authorization-APIGWs": {  # not called for in a ticket, but thrown in anyway 
      "dashboard_type" : "apigw", 
      "names": [
        "regional-authorization" 
      ]
    }
  },
  {            
   "timtest-ddb-dashboard": {  # not called for in a ticket, but thrown in anyway 
     "dashboard_type" : "dynamodb", 
     "names": [
       "exception-hub-data-store",
       "tsa-cache",
       "uim-entitlement-store",
       "uim-user",
       "uim-user-testbackup"
     ]
   }
  }, 
  {               
    "timtest-s3-dashboard": {  # not called for in a ticket, but thrown in anyway 
      "dashboard_type" : "s3", 
      "names": [
        'acme-dev-certificate',
        'acme-dev-data-exception',
        'acme-dev-data-uim-parm',
        'acme-dev-data-uim-user',
        'acme-dev-dynamodb-data',
        'acme-dev-inventory',
        'acme-dev-lambda-source-code',
        'acme-dev-logs',
        'acme-dev-ui-source-code'
      ]
    }
  } 
]

for dashboard in dashboards:
    for dashboard_name, details in dashboard.items(): 
        dashboard_type = details['dashboard_type']
        for name in details['names']:
            print("dashboard_type", dashboard_type, "dashboard_name", dashboard_name, "name ", name)
            if dashboard_type == 'lambda':
                resource = f'arn:aws:lambda:us-east-1:924289411007:function:acme-dev-{name}'
                lambda_client.tag_resource(Resource=resource, Tags={"CloudwatchDashboardBasenames": dashboard_name})
            elif dashboard_type == 'apigw':
                rest_id = name_to_id[f'acme-dev-{name}']
                resource = f'arn:aws:apigateway:us-east-1::/restapis/{rest_id}'
                print("resource", resource)
                apigw_client.tag_resource(resourceArn=resource,tags={"CloudwatchDashboardBasenames": dashboard_name})
            elif dashboard_type == 'dynamodb':
                resource = f'arn:aws:dynamodb:us-east-1:924289411007:table/acme-dev-{name}'
                print("resource", resource)
                dynamodb_client.tag_resource(ResourceArn=resource,
                  Tags=[{"Key": "CloudwatchDashboardBasenames", "Value": dashboard_name}])
            elif dashboard_type == 's3':
                s3_client.put_bucket_tagging(Bucket=name,
                  Tagging={'TagSet': [
                     { "Key": "CloudwatchDashboardBasenames", "Value": dashboard_name}
                  ]})
            else:
                print('unknowh dashboard type', dashboard_type)
