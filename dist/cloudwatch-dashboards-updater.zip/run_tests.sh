#!/bin/bash
PYTHONPATH=. python lib/unit_tests.py
